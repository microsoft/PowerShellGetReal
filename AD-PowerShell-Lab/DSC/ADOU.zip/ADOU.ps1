﻿$root = New-Object System.DirectoryServices.DirectoryEntry

$OUsToStage = @(
"OU=Production"
"OU=PCs,OU=Production"
"OU=People,OU=Production"
"OU=Servers,OU=Production"
"OU=Workstations,OU=Production"
"OU=Groups,OU=People,OU=Production"
"OU=Remote,OU=People,OU=Production"
)
$OUsToCreate =foreach ($OU in $OUsToStage) {
    $OU + ',' + $root.distinguishedName
}

$OUObjs = foreach ($OU in $OUsToCreate) {
    [pscustomobject]@{
        Name = $OU.Split(',',2)[0].replace('OU=','')
        Path = $OU.Split(',',2)[1]
    }   
}

configuration CreateDomainOU
{ 
    param 
    ( 

        [Parameter(HelpMessage='Timestamp used solely as a mechanism to force ARM to redeploy DSC resources because the parameters have changed.')]
        [string]$Timestamp
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration, ActiveDirectoryDSC

    Node localhost
    {
        foreach ($OU in $OUObjs){
            ADOrganizationalUnit "Create$($OU.name) $((New-Guid).Guid)"
                {
                    Name = $OU.Name
                    Path = $OU.Path
                }
        }
        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
}