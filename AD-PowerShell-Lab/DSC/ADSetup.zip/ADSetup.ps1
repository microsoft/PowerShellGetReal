﻿configuration CreateADPDC 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount = 5,
        [Int]$RetryIntervalSec = 10
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration, ActiveDirectoryDSC, xDnsServer
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        WindowsFeature 'ADDSInstall' { 
            Name = "AD-Domain-Services"
            IncludeAllSubFeature = $true
        }

        WindowsFeature 'RSATInstall' { 
            Name      = "RSAT-ADDS"
            DependsOn = '[WindowsFeature]ADDSInstall'
        }
        
        ADDomain FirstDC
        {
            DomainName                    = $DomainName
            Credential                    = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn                     = "[WindowsFeature]RSATInstall"
        }

        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
}

configuration CreateSecondDC 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount = 5,
        [Int]$RetryIntervalSec = 10
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration, ActiveDirectoryDSC, xDnsServer
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        WindowsFeature 'ADDSInstall' { 
            Name                 = "AD-Domain-Services"
            IncludeAllSubFeature = $true
        }

        WindowsFeature 'RSATInstall' { 
            Name      = "RSAT-ADDS"
            DependsOn = '[WindowsFeature]ADDSInstall'
        }

        ADDomainController AddSecondDC
        {
            DomainName                    = $DomainName
            Credential                    = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DependsOn                     = "[WindowsFeature]RSATInstall"
        }

        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
}

configuration JoinAD 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 
    Import-DscResource -ModuleName PSDesiredStateConfiguration, ActiveDirectoryDSC, xDSCDomainJoin
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        xDSCDomainJoin "Join$Domain"
        {
            Domain     = $DomainName
            Credential = $DomainCreds
        }

        LocalConfigurationManager {
            ConfigurationMode  = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
} 